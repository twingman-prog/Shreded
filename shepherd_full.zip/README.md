Shepherd - Android (Full version)
================================
This is the full Shepherd Android starter project with per-app limits and an AccessibilityService skeleton.

How to build:
- Open the project in Android Studio.
- Build > Build APK(s) or Build > Generate Signed Bundle / APK for a release AAB.
- Grant Usage Access in Settings for the app to read usage stats.
- To enable enforcement, enable the Accessibility Service in Settings -> Accessibility -> Shepherd.

License: Customize as needed.
