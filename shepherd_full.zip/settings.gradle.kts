rootProject.name = "Shepherd"
include(":app")
