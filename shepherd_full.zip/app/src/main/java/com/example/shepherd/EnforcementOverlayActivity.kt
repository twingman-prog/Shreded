package com.example.shepherd

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class EnforcementOverlayActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pkg = intent.getStringExtra(EXTRA_PKG) ?: ""
        setContent {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(text = "Time's up for $pkg")
                    Spacer(modifier = Modifier.height(12.dp))
                    Button(onClick = { finish() }) { Text("Close") }
                }
            }
        }
    }

    companion object {
        private const val EXTRA_PKG = "extra_pkg"
        fun createIntent(ctx: Context, pkg: String): Intent {
            return Intent(ctx, EnforcementOverlayActivity::class.java).putExtra(EXTRA_PKG, pkg)
        }
    }
}
