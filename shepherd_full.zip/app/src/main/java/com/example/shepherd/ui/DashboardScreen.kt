package com.example.shepherd.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.shepherd.AppUsage
import com.example.shepherd.DashboardViewModel

@Composable
fun DashboardScreen(vm: DashboardViewModel) {
    val state = vm.uiState.collectAsState()
    Column(modifier = Modifier.fillMaxSize().padding(8.dp)) {
        Text(text = "Shepherd", style = androidx.compose.material3.MaterialTheme.typography.headlineMedium)
        Spacer(modifier = Modifier.height(8.dp))
        Text(text = "Total today: ${formatMillis(state.value.totalToday)}")
        Spacer(modifier = Modifier.height(8.dp))
        LazyColumn(modifier = Modifier.fillMaxWidth()) {
            items(state.value.apps) { app ->
                AppRow(app)
            }
        }
    }
}

@Composable
fun AppRow(app: AppUsage) {
    Row(modifier = Modifier
        .fillMaxWidth()
        .padding(vertical = 8.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(text = app.packageName, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(text = formatMillis(app.millis))
    }
}

fun formatMillis(millis: Long): String {
    val sec = millis / 1000
    val m = sec / 60
    val s = sec % 60
    return "${m}m ${String.format("%02d", s)}s"
}
