package com.example.shepherd

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    private val vm: DashboardViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        com.example.shepherd.ui.DashboardScreen(vm)
                        Spacer(modifier = Modifier.height(12.dp))
                        Button(onClick = { openUsageAccessSettings() }) {
                            Text("Open Usage Access Settings")
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Button(onClick = { vm.refresh() }) {
                            Text("Refresh")
                        }
                    }
                }
            }
        }
    }

    private fun openUsageAccessSettings() {
        startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
    }
}
