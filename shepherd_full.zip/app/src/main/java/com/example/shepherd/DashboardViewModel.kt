package com.example.shepherd

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.*

class DashboardViewModel(application: Application) : AndroidViewModel(application) {
    private val helper = UsageStatsHelper(application)
    private val _uiState = MutableStateFlow(DashboardUiState())
    val uiState: StateFlow<DashboardUiState> = _uiState.asStateFlow()

    init {
        refresh()
    }

    fun refresh() {
        viewModelScope.launch(Dispatchers.Default) {
            val cal = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, 0)
                set(Calendar.MINUTE, 0)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
            }
            val start = cal.timeInMillis
            val end = System.currentTimeMillis()
            val map = helper.queryUsageMap(start, end)
            val list = map.map { AppUsage(it.key, it.value) }
                .sortedByDescending { it.millis }
            _uiState.value = DashboardUiState(
                totalToday = list.sumOf { it.millis },
                apps = list
            )
        }
    }
}

data class DashboardUiState(
    val totalToday: Long = 0L,
    val apps: List<AppUsage> = emptyList()
)

data class AppUsage(val packageName: String, val millis: Long)
