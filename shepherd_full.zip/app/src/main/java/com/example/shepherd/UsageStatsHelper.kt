package com.example.shepherd

import android.app.usage.UsageStatsManager
import android.content.Context

class UsageStatsHelper(private val context: Context) {
    private val usageManager = context.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager

    fun queryUsageMap(startMillis: Long, endMillis: Long): Map<String, Long> {
        val aggregated = usageManager.queryAndAggregateUsageStats(startMillis, endMillis)
        val result = mutableMapOf<String, Long>()
        for ((pkg, stats) in aggregated) {
            result[pkg] = stats.totalTimeInForeground
        }
        return result
    }
}
