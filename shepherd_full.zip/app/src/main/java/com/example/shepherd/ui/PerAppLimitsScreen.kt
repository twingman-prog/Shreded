package com.example.shepherd.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.shepherd.LimitsRepository
import kotlinx.coroutines.launch

@Composable
fun PerAppLimitsScreen(pkg: String, repo: LimitsRepository) {
    val scope = rememberCoroutineScope()
    var minutes by remember { mutableStateOf(0) }
    LaunchedEffect(pkg) {
        repo.getLimitFlow(pkg).collect { ms ->
            minutes = (ms/60000).toInt()
        }
    }

    Column(modifier = Modifier.fillMaxWidth().padding(16.dp)) {
        Text(text = "Set daily limit for: $pkg")
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = if (minutes==0) "" else minutes.toString(), onValueChange = { v ->
            minutes = v.filter { it.isDigit() }.let { if (it.isEmpty()) 0 else it.toInt() }
        }, label = { Text("Minutes per day") })
        Spacer(Modifier.height(12.dp))
        Row {
            Button(onClick = {
                scope.launch { repo.setLimit(pkg, minutes * 60L * 1000L) }
            }) { Text("Save") }
            Spacer(modifier = Modifier.width(8.dp))
            Button(onClick = {
                scope.launch { repo.clearLimit(pkg) }
            }) { Text("Clear") }
        }
    }
}
