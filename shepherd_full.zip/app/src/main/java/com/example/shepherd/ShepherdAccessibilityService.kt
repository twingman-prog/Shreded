package com.example.shepherd

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.launch

class ShepherdAccessibilityService : AccessibilityService() {
    private val scope = CoroutineScope(Dispatchers.Default)
    private val limitsRepo by lazy { LimitsRepository(applicationContext) }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        if (event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED ||
            event.eventType == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED) {
            val pkg = event.packageName?.toString() ?: return
            scope.launch {
                val limit = limitsRepo.getLimitFlow(pkg).firstOrNull() ?: 0L
                if (limit > 0L) {
                    val helper = UsageStatsHelper(applicationContext)
                    val start = startOfDayMillis()
                    val end = System.currentTimeMillis()
                    val map = helper.queryUsageMap(start, end)
                    val used = map[pkg] ?: 0L
                    if (used >= limit) {
                        val i = EnforcementOverlayActivity.createIntent(applicationContext, pkg)
                        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        startActivity(i)
                    }
                }
            }
        }
    }

    override fun onInterrupt() {}

    private fun startOfDayMillis(): Long {
        val cal = java.util.Calendar.getInstance().apply {
            set(java.util.Calendar.HOUR_OF_DAY, 0)
            set(java.util.Calendar.MINUTE, 0)
            set(java.util.Calendar.SECOND, 0)
            set(java.util.Calendar.MILLISECOND, 0)
        }
        return cal.timeInMillis
    }
}
