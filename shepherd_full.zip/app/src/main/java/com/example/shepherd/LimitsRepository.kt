package com.example.shepherd

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore("shepherd_prefs")

class LimitsRepository(private val context: Context) {
    private fun keyForPackage(pkg: String) = longPreferencesKey("limit_$pkg")

    fun getLimitFlow(pkg: String): Flow<Long> = context.dataStore.data.map { prefs ->
        prefs[keyForPackage(pkg)] ?: 0L // 0 = no limit
    }

    suspend fun setLimit(pkg: String, ms: Long) {
        context.dataStore.edit { prefs ->
            prefs[keyForPackage(pkg)] = ms
        }
    }

    suspend fun clearLimit(pkg: String) {
        context.dataStore.edit { prefs ->
            prefs.remove(keyForPackage(pkg))
        }
    }
}
